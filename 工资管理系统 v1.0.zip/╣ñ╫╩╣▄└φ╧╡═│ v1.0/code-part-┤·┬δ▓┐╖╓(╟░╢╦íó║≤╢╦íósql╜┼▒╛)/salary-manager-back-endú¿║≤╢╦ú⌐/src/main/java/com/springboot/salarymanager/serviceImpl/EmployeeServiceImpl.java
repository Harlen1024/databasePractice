package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Employee;
import com.springboot.salarymanager.mapper.EmployeeMapper;
import com.springboot.salarymanager.service.EmployeeService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeMapper employeeMapper;

    @Override
    public Employee queryEmployeeByEm_num(String em_num){

        Employee employee = this.employeeMapper.queryEmployeeByEm_num(em_num);

        return employee;
    }

    @Override
    public int updateEmploy(Employee employee){

        int temp = this.employeeMapper.updateEmploy(employee);

        return temp;
    }
}
