package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Company;
import com.springboot.salarymanager.entity.Department;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface CompanyMapper {

    //按年份查询
    @Select("SELECT * FROM t_company WHERE year like '%${value}%'")
    Company queryCompanyByYear(int year);

}
