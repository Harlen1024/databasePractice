package com.springboot.salarymanager.tool;

import java.sql.*;

public class Test {
    public static void main(String[] args) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlserver://47.95.3.253:1433; DatabaseName=master",
                "sa", "admin111");

        Statement s = conn.createStatement();
        String sql = "select * from t_department";
        ResultSet set = s.executeQuery(sql);
        while (set.next()) {
            System.out.println(set.getObject(5).getClass().getName());
        }
    }
}
