package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Login;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LoginMapper {

    //按工号查找
    @Select("SELECT * FROM t_login WHERE em_num like '%${value}%'")
    Login queryReaderByEm_num(String em_num);
}
