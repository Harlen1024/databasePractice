package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Company;

public interface CompanyService {

    Company queryCompanyByYear(int year);

}
