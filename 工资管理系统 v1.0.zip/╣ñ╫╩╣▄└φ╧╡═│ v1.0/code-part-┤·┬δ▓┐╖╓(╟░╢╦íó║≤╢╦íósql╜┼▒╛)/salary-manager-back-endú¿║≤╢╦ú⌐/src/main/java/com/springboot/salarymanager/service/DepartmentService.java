package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Department;

import java.util.List;

public interface DepartmentService {

    List<Department> getAllDepartment();

    Department queryEmployeeByDep_id(String dep_id);

}
