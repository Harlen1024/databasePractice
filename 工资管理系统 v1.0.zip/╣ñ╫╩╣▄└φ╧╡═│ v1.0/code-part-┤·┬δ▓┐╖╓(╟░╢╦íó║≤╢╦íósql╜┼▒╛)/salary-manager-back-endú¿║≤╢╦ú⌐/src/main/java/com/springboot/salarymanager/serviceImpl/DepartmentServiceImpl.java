package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Department;
import com.springboot.salarymanager.mapper.DepartmentMapper;
import com.springboot.salarymanager.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Override
    public List<Department> getAllDepartment() {

        List<Department> list = this.departmentMapper.getAllDepartment();

        return list;

    }

    @Override
    public Department queryEmployeeByDep_id(String dep_id){

        Department department = this.departmentMapper.queryEmployeeByDep_id(dep_id);

        return department;
    }

}
