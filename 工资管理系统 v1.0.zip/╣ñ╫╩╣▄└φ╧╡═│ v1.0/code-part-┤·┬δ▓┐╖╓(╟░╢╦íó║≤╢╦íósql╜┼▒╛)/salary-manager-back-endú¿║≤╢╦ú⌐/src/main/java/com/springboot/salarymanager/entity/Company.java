package com.springboot.salarymanager.entity;

/**
 * 公司信息实体类
 * year:年份
 * total_turnover:公司总营业额
 * total_salary:公司总工资
 * total_employee:公司总人数
 */

public class Company {

    private int year;

    private int total_turnover;

    private long total_salary;

    private int total_employee;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getTotal_turnover() {
        return total_turnover;
    }

    public void setTotal_turnover(int total_turnover) {
        this.total_turnover = total_turnover;
    }

    public long getTotal_salary() {
        return total_salary;
    }

    public void setTotal_salary(long total_salary) {
        this.total_salary = total_salary;
    }

    public int getTotal_employee() {
        return total_employee;
    }

    public void setTotal_employee(int total_employee) {
        this.total_employee = total_employee;
    }
}
