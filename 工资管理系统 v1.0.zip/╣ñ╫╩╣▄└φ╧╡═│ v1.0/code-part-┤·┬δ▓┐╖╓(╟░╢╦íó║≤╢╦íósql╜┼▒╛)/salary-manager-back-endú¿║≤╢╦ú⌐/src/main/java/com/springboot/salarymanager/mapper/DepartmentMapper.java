package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Department;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.type.JdbcType;

import java.util.List;

@Mapper
public interface DepartmentMapper {

    //查询全部
    @Select("select * from t_department")
    @Results(id = "departmentMapper", value = {
            @Result(property = "salary", column = "dep_tot_salary", javaType = java.lang.Long.class, jdbcType = JdbcType.BIGINT) ,
            @Result(property = "turnover", column = "dep_tot_turnover", javaType = java.lang.Long.class, jdbcType = JdbcType.BIGINT)


    })
    List<Department> getAllDepartment();

    //按部门id查询
    @Select("SELECT * FROM t_department WHERE dep_id like '%${value}%'")
    Department queryEmployeeByDep_id(String dep_id);

}
