package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Company;
import com.springboot.salarymanager.mapper.CompanyMapper;
import com.springboot.salarymanager.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CompanyServiceImpl implements CompanyService {

    @Autowired
    private CompanyMapper companyMapper;

    @Override
    public Company queryCompanyByYear(int year){

        Company company = this.companyMapper.queryCompanyByYear(year);

        return company;
    }
}
