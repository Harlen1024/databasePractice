package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Job;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface JobMapper {

    //按job_id查找
    @Select("SELECT * FROM t_job WHERE job_id like '%${value}%'")
    Job queryJobByJob_id(String job_id);

}
