package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Job;

public interface JobService {

    Job queryJobByJob_id(String job_id);

}
