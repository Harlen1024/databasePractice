package com.springboot.salarymanager.entity;

/**
 * 员工基本信息实体类
 * em_num:工号
 * em_name:员工姓名
 * em_sex:员工性别（int） 0：男 1：女
 * em_id:员工身份证号
 * em_birth:员工生日
 * em_nation:员工民族
 * em_regist:员工户籍
 * em_addr:员工住址
 * job_age:员工工龄
 * job_id:员工工作类型
 * 1：董事部 2：技术部（部门经理） 3：运营部（部门经理） 4：销售部（部门经理） 5：行政部（部门经理）
 * 6：技术部（职员） 7：运营部（职员） 8：销售部（职员） 9：行政部（职员）
 */


public class Employee {

	//工号
	private String em_num;

	//员工姓名
	private String em_name;

	//员工性别
	private String em_sex;

	//员工身份证
	private String em_id;

	//员工生日
	private String em_birth;

	//员工民族
	private String em_nation;

	//员工户籍
	private String em_regist;

	//员工住址
	private String em_addr; //住址

	//员工工龄
	private int job_age;

	//员工工作类型
	private int job_id;

	public String getEm_num() {
		return em_num;
	}

	public void setEm_num(String em_num) {
		this.em_num = em_num;
	}

	public String getEm_name() {
		return em_name;
	}

	public void setEm_name(String em_name) {
		this.em_name = em_name;
	}

	public String getEm_sex() {
		return em_sex;
	}

	public void setEm_sex(String em_sex) {
		this.em_sex = em_sex;
	}

	public String getEm_id() {
		return em_id;
	}

	public void setEm_id(String em_id) {
		this.em_id = em_id;
	}

	public String getEm_birth() {
		return em_birth;
	}

	public void setEm_birth(String em_birth) {
		this.em_birth = em_birth;
	}

	public String getEm_nation() {
		return em_nation;
	}

	public void setEm_nation(String em_nation) {
		this.em_nation = em_nation;
	}

	public String getEm_regist() {
		return em_regist;
	}

	public void setEm_regist(String em_regist) {
		this.em_regist = em_regist;
	}

	public String getEm_addr() {
		return em_addr;
	}

	public void setEm_addr(String em_addr) {
		this.em_addr = em_addr;
	}

	public int getJob_age() {
		return job_age;
	}

	public void setJob_age(int job_age) {
		this.job_age = job_age;
	}

	public int getJob_id() {
		return job_id;
	}

	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
}
