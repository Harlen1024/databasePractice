package com.springboot.salarymanager.controller;

import com.springboot.salarymanager.entity.Employee;
import com.springboot.salarymanager.entity.Login;
import com.springboot.salarymanager.service.EmployeeService;
import com.springboot.salarymanager.service.LoginService;
import com.springboot.salarymanager.tool.jsontool.JsonResult;
import com.springboot.salarymanager.tool.md5tool.Md5Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/** 所有的post请求的接口
 *  1./api/append/login 登录用api 键值为二 value = em_num && password 成功返回员工类型 失败返回“defeat”
 *  2./api/update/employee 更新用户基本信息的接口 post为一个json整体
 */


@RestController
@CrossOrigin
@RequestMapping("/api")
public class PostController {

    @Autowired
    private LoginService loginService;

    @Autowired
    private EmployeeService employeeService;

    //根据用户名登录
    @RequestMapping(value = "/append/login", method = RequestMethod.POST)
    public JsonResult readerLogin(@RequestParam(value = "em_num") String em_num,
                                  @RequestParam(value = "password") String password) {

        Login login = this.loginService.queryReaderByEm_num(em_num);

        //密码不正确时的实例
        Login wrong_login = new Login();

        //MD5加密
        Md5Result getMD5 = new Md5Result();

        if(login != null) {
            if (login.getPassword().equals(getMD5.getMD5Code(password))) {

                login.setLogin_state("true");
                return JsonResult.ok(login);

            }
        }

        wrong_login.setEm_num(em_num);
        wrong_login.setPassword(password);
        wrong_login.setType(-1);
        wrong_login.setLogin_state("false");

        return JsonResult.ok(wrong_login);

    }

    @RequestMapping(value = "update/employee", method = RequestMethod.POST)
    public Map<String, Object> getArticle(@RequestBody Employee employee) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("employee", employee);
//        employeeService.updateEmploy(employee, employee.getEm_num());
//        System.out.println(employee.getEm_num());
        employeeService.updateEmploy(employee);
        return param;
    }


}
