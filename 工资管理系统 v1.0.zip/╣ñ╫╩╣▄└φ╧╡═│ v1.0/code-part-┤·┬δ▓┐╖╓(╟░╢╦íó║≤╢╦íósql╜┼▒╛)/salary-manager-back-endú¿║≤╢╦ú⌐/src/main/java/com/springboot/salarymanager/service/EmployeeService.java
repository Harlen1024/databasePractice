package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Employee;

public interface EmployeeService {

    Employee queryEmployeeByEm_num(String em_num);

    int updateEmploy(Employee employee);

}
