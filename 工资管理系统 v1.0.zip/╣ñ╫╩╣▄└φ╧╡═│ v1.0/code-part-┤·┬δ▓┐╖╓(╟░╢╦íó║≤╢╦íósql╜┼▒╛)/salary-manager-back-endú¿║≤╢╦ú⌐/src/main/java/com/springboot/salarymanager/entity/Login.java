package com.springboot.salarymanager.entity;

/**
 * 登陆用实体类
 * em_num:工号
 * password:密码（MD5加密）
 * type:员工类型（int） 1：董事长 2：部门主管 3：普通员工
 * login_state:登录状态 true/false
 */

public class Login {

    //工号
    private String em_num;

    //密码（经MD5加密）
    private String password;

    //type:员工类型（int） 1：董事长 2：部门主管 3：普通员工
    private int type;

    //登录状态 true/false
    private String login_state;

    public String getEm_num() {
        return em_num;
    }

    public void setEm_num(String em_num) {
        this.em_num = em_num;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getLogin_state() {
        return login_state;
    }

    public void setLogin_state(String login_state) {
        this.login_state = login_state;
    }
}
