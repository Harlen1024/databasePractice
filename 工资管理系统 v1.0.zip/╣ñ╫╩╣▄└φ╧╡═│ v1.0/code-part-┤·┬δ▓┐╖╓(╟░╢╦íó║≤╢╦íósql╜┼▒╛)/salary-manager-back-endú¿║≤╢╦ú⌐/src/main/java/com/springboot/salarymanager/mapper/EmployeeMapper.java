package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Employee;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface EmployeeMapper {

    //按工号查询
	@Select("SELECT * FROM t_employee_info WHERE em_num like '%${value}%'")
	Employee queryEmployeeByEm_num(String em_num);

	//更新个人信息
	@Update("UPDATE t_employee_info SET " +
			"em_name=#{em_name}, " +
			"em_sex=#{em_sex}, " +
			"em_id=#{em_id}, " +
			"em_birth=#{em_birth}, " +
			"em_nation=#{em_nation}, " +
			"em_regist=#{em_regist} , " +
			"em_addr=#{em_addr} " +
			"WHERE em_num=#{em_num}")
    //@Update("UPDATE t_employee_info SET em_sex=#{em_sex}, em_name=#{em_name} WHERE em_num=#{em_num}")
	int updateEmploy(Employee employee);

}
