package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Login;
import com.springboot.salarymanager.mapper.LoginMapper;
import com.springboot.salarymanager.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginMapper loginMapper;

    @Override
    public Login queryReaderByEm_num(String em_num){

        Login login = this.loginMapper.queryReaderByEm_num(em_num);

        return login;
    }


}