package com.springboot.salarymanager.entity;

/**
 * 职位信息实体类
 * job_id:员工工作类型
 * job_name:职位名称
 * job_dep:对应部门
 * base_salary:基本薪资
 */

public class Job {

    //员工工作类型
    private int job_id;

    //职位名称
    private String job_name;

    //对应部门
    private int job_dep;

    //基本薪资
    private int base_salary;

    public int getJob_id() {
        return job_id;
    }

    public void setJob_id(int job_id) {
        this.job_id = job_id;
    }

    public String getJob_name() {
        return job_name;
    }

    public void setJob_name(String job_name) {
        this.job_name = job_name;
    }

    public int getJob_dep() {
        return job_dep;
    }

    public void setJob_dep(int job_dep) {
        this.job_dep = job_dep;
    }

    public int getBase_salary() {
        return base_salary;
    }

    public void setBase_salary(int base_salary) {
        this.base_salary = base_salary;
    }
}
