package com.springboot.salarymanager.entity;

/**
 * 工资信息实体类
 * id:id
 * em_num:工号
 * base_salary:基础工资
 * attendance:出勤天数
 * bonus:全勤奖金
 * attend_bonus:出勤奖金
 * calculate_salary:应发工资
 * =IF(出勤天数>=30,全勤奖金+出勤天数*出勤奖金,IF(出勤天数<30,出勤天数*出勤奖金))
 * deduction:扣除工资
 * actual_salary:实发工资
 * month:月份
 */
public class Salary {

    private int id;

    private String em_num;

    private int base_salary;

    private int attendance;

    private int bonus;

    private int attend_bonus;

    private int calculate_salary;

    private int deduction;

    private int actual_salary;

    private int month;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEm_num() {
        return em_num;
    }

    public void setEm_num(String em_num) {
        this.em_num = em_num;
    }

    public int getBase_salary() {
        return base_salary;
    }

    public void setBase_salary(int base_salary) {
        this.base_salary = base_salary;
    }

    public int getAttendance() {
        return attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public int getAttend_bonus() {
        return attend_bonus;
    }

    public void setAttend_bonus(int attend_bonus) {
        this.attend_bonus = attend_bonus;
    }

    public int getCalculate_salary() {
        return calculate_salary;
    }

    public void setCalculate_salary(int calculate_salary) {
        this.calculate_salary = calculate_salary;
    }

    public int getDeduction() {
        return deduction;
    }

    public void setDeduction(int deduction) {
        this.deduction = deduction;
    }

    public int getActual_salary() {
        return actual_salary;
    }

    public void setActual_salary(int actual_salary) {
        this.actual_salary = actual_salary;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
}
