package com.springboot.salarymanager.entity;

/**
 * 部门基本信息实体类
 * dep_id:部门号
 * dep_name:部门名
 * dep_em:部门员工数
 * dep_tol_turnover:部门总营业额
 * dep_tol_salary:部门总工资
 */

public class Department {

    private int dep_id;

    private String dep_name;

    private int dep_em;

    private Long turnover;

    private Long salary;

    public int getDep_id() {
        return dep_id;
    }

    public void setDep_id(int dep_id) {
        this.dep_id = dep_id;
    }

    public String getDep_name() {
        return dep_name;
    }

    public void setDep_name(String dep_name) {
        this.dep_name = dep_name;
    }

    public int getDep_em() {
        return dep_em;
    }

    public void setDep_em(int dep_em) {
        this.dep_em = dep_em;
    }

    public Long getDep_tol_turnover() {
        return turnover;
    }

    public void setTurnover(Long dep_tol_turnover) {
        this.turnover = dep_tol_turnover;
    }

    public Long getDep_tol_salary() {
        return salary;
    }

    public void setSalary(Long dep_tol_salary) {
        this.salary = dep_tol_salary;
    }
}
