package com.springboot.salarymanager.controller;

import com.springboot.salarymanager.entity.*;
import com.springboot.salarymanager.excel.ReadExcelUtils;
import com.springboot.salarymanager.service.*;
import com.springboot.salarymanager.tool.jsontool.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.FileNotFoundException;
import java.util.*;

/** 所有的get请求的接口
 *  1./api/excel/{EXCEL} 上传本地本月excel内工资信息（测试用）
 *  2./api/query/employee/em_num/{em_num} 根据工号查询员工基本信息
 *  3./api/query/salary/em_num/{em_num}/{month} 根据工号&月份查询员工当月工资信息
 *  4./api/query/job/job_id/{job_id} 根据job_id查询工作表中的工作类型
 *  5./api/query/dep/dep_id/{dep_id} 根据dep_id查询部门表中的部门类型
 *  6./api/query/salary/department/{department} 根据部门查询所有员工当月工资信息
 *  7./api/query/department/all 查询全部部门信息
 *  8./api/query/company/year/{year} 查询全部部门信息
 *  9./api/query/salary/em_num/{em_num} 根据工号查询员工当月工资信息
 */

@RestController
@CrossOrigin
@RequestMapping("/api")
public class GetController {

    @Autowired
    private SalaryService salaryService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private JobService jobService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private CompanyService companyService;

    //mysql本地上传excel工资信息（测试用）
    @RequestMapping("excel/{EXCEL}")
    public JsonResult uploadExcel(@PathVariable String EXCEL) {

        Salary salary = new Salary();

        try {
            String filepath = EXCEL;
            ReadExcelUtils excelReader = new ReadExcelUtils(filepath);
            // 对读取Excel表格标题测试
//			String[] title = excelReader.readExcelTitle();
//			System.out.println("获得Excel表格的标题:");
//			for (String s : title) {
//				System.out.print(s + " ");
//			}

            // 对读取Excel表格内容测试
            Map<Integer, Map<Integer,Object>> map = excelReader.readExcelContent();
            System.out.println("获得Excel表格的内容:");
            for (int i = 1; i <= map.size(); i++) {
                salary.setEm_num(map.get(i).get(0).toString());
                salary.setBase_salary(Integer.parseInt(map.get(i).get(1).toString().substring(0,map.get(i).get(1).toString().indexOf("."))));
                salary.setAttendance(Integer.parseInt(map.get(i).get(2).toString().substring(0,map.get(i).get(2).toString().indexOf("."))));
                salary.setBonus(Integer.parseInt(map.get(i).get(3).toString().substring(0,map.get(i).get(3).toString().indexOf("."))));
                salary.setAttend_bonus(Integer.parseInt(map.get(i).get(4).toString().substring(0,map.get(i).get(4).toString().indexOf("."))));
                salary.setCalculate_salary(Integer.parseInt(map.get(i).get(5).toString().substring(0,map.get(i).get(5).toString().indexOf("."))));
                salary.setDeduction(Integer.parseInt(map.get(i).get(6).toString().substring(0,map.get(i).get(6).toString().indexOf("."))));
                salary.setActual_salary(Integer.parseInt(map.get(i).get(7).toString().substring(0,map.get(i).get(7).toString().indexOf("."))));
                salary.setMonth(Integer.parseInt(map.get(i).get(8).toString().substring(0,map.get(i).get(8).toString().indexOf("."))));
                salaryService.insertSalary(salary);
            }
        } catch (FileNotFoundException e) {
            System.out.println("未找到指定路径的文件!");
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }

        return JsonResult.ok("success");

    }

    //mysql单类型查询()
    @RequestMapping("query/employee/em_num/{em_num}")
    public JsonResult queryEmployeeByEm_num(@PathVariable String em_num) {

        Employee employee = this.employeeService.queryEmployeeByEm_num(em_num);

        return JsonResult.ok(employee);

    }

    //mysql单类型查询()
    @RequestMapping("query/salary/em_num/{em_num}/{month}")
    public JsonResult querySalaryByEm_num(@PathVariable String em_num, @PathVariable String month) {

        int MONTH = Integer.parseInt(month);

        Salary salary = this.salaryService.querySalaryByEm_numAndMonth(em_num, MONTH);

        return JsonResult.ok(salary);

    }

    //mysql单类型查询()
    @RequestMapping("query/job/job_id/{job_id}")
    public JsonResult querySalaryByJob_id(@PathVariable String job_id) {

        Job job = this.jobService.queryJobByJob_id(job_id);

        return JsonResult.ok(job);

    }

    //mysql单类型查询()
    @RequestMapping("query/dep/dep_id/{dep_id}")
    public JsonResult queryDepByJob_id(@PathVariable String dep_id) {

        Department department = this.departmentService.queryEmployeeByDep_id(dep_id);

        return JsonResult.ok(department);

    }

    //获取mysql中全部数据
    @RequestMapping("query/salary/department/{department}")
    public JsonResult querySalaryByDepartment(@PathVariable String department) {

        int DEP = Integer.parseInt(department);

        List<Salary> list = this.salaryService.getAllSalary();

        List<DepartmentSalaryGet> sal_list = new ArrayList<>();

        for(int i = 0 ; i<list.size() ; i++){

            Employee employee = this.employeeService.queryEmployeeByEm_num(list.get(i).getEm_num());

            if(DEP==1){

                if(employee.getJob_id() == 6|| employee.getJob_id() == 2){

                    DepartmentSalaryGet departmentSalaryGet = new DepartmentSalaryGet();

                    departmentSalaryGet.setEm_num(list.get(i).getEm_num());
                    departmentSalaryGet.setEm_name(employee.getEm_name());
                    if(employee.getJob_id() == 6){
                        departmentSalaryGet.setJob_name("产品经理");
                    }
                    else{
                        departmentSalaryGet.setJob_name("职员");
                    }
                    departmentSalaryGet.setBase_salary(list.get(i).getBase_salary());
                    departmentSalaryGet.setAttendance(list.get(i).getAttendance());
                    departmentSalaryGet.setAttend_bonus(list.get(i).getAttend_bonus());
                    departmentSalaryGet.setBonus(list.get(i).getBonus());
                    departmentSalaryGet.setCalculate_salary(list.get(i).getCalculate_salary());
                    departmentSalaryGet.setDeduction(list.get(i).getDeduction());
                    departmentSalaryGet.setActual_salary(list.get(i).getActual_salary());
                    departmentSalaryGet.setMonth(list.get(i).getMonth());

                    sal_list.add(departmentSalaryGet);
                }

            }
            else if(DEP==2){

                if(employee.getJob_id() == 7|| employee.getJob_id() == 3){

                    DepartmentSalaryGet departmentSalaryGet = new DepartmentSalaryGet();

                    departmentSalaryGet.setEm_num(list.get(i).getEm_num());
                    departmentSalaryGet.setEm_name(employee.getEm_name());
                    if(employee.getJob_id() == 7){
                        departmentSalaryGet.setJob_name("产品经理");
                    }
                    else{
                        departmentSalaryGet.setJob_name("职员");
                    }
                    departmentSalaryGet.setBase_salary(list.get(i).getBase_salary());
                    departmentSalaryGet.setAttendance(list.get(i).getAttendance());
                    departmentSalaryGet.setAttend_bonus(list.get(i).getAttend_bonus());
                    departmentSalaryGet.setBonus(list.get(i).getBonus());
                    departmentSalaryGet.setCalculate_salary(list.get(i).getCalculate_salary());
                    departmentSalaryGet.setDeduction(list.get(i).getDeduction());
                    departmentSalaryGet.setActual_salary(list.get(i).getActual_salary());
                    departmentSalaryGet.setMonth(list.get(i).getMonth());

                    sal_list.add(departmentSalaryGet);
                }

            }

            else if(DEP==3){

                if(employee.getJob_id() == 8|| employee.getJob_id() == 4){

                    DepartmentSalaryGet departmentSalaryGet = new DepartmentSalaryGet();

                    departmentSalaryGet.setEm_num(list.get(i).getEm_num());
                    departmentSalaryGet.setEm_name(employee.getEm_name());
                    if(employee.getJob_id() == 7){
                        departmentSalaryGet.setJob_name("产品经理");
                    }
                    else{
                        departmentSalaryGet.setJob_name("职员");
                    }
                    departmentSalaryGet.setBase_salary(list.get(i).getBase_salary());
                    departmentSalaryGet.setAttendance(list.get(i).getAttendance());
                    departmentSalaryGet.setAttend_bonus(list.get(i).getAttend_bonus());
                    departmentSalaryGet.setBonus(list.get(i).getBonus());
                    departmentSalaryGet.setCalculate_salary(list.get(i).getCalculate_salary());
                    departmentSalaryGet.setDeduction(list.get(i).getDeduction());
                    departmentSalaryGet.setActual_salary(list.get(i).getActual_salary());
                    departmentSalaryGet.setMonth(list.get(i).getMonth());

                    sal_list.add(departmentSalaryGet);
                }

            }

            else if(DEP==4) {

                if (employee.getJob_id() == 9 || employee.getJob_id() == 5) {

                    DepartmentSalaryGet departmentSalaryGet = new DepartmentSalaryGet();

                    departmentSalaryGet.setEm_num(list.get(i).getEm_num());
                    departmentSalaryGet.setEm_name(employee.getEm_name());
                    if (employee.getJob_id() == 7) {
                        departmentSalaryGet.setJob_name("产品经理");
                    } else {
                        departmentSalaryGet.setJob_name("职员");
                    }
                    departmentSalaryGet.setBase_salary(list.get(i).getBase_salary());
                    departmentSalaryGet.setAttendance(list.get(i).getAttendance());
                    departmentSalaryGet.setAttend_bonus(list.get(i).getAttend_bonus());
                    departmentSalaryGet.setBonus(list.get(i).getBonus());
                    departmentSalaryGet.setCalculate_salary(list.get(i).getCalculate_salary());
                    departmentSalaryGet.setDeduction(list.get(i).getDeduction());
                    departmentSalaryGet.setActual_salary(list.get(i).getActual_salary());
                    departmentSalaryGet.setMonth(list.get(i).getMonth());

                    sal_list.add(departmentSalaryGet);
                }

            }

        }

        return JsonResult.ok(sal_list);

    }


    //mysql单类型查询()
    @RequestMapping("query/department/all")
    public JsonResult queryDepByJob_id() {

        List<Department> list = this.departmentService.getAllDepartment();

        return JsonResult.ok(list);

    }

    //获取mysql中reader表全部数据
    @RequestMapping("query/company/year/{year}")
    public JsonResult queryCompanyByYear(@PathVariable String year) {

        int YEAR = Integer.parseInt(year);

        Company company = this.companyService.queryCompanyByYear(YEAR);

        return JsonResult.ok(company);

    }


    //获取mysql中reader表全部数据
    @RequestMapping("query/salary/em_num/{em_num}")
    public JsonResult queryCompanyByEm_num(@PathVariable String em_num) {

        List<Salary> list = this.salaryService.querySalaryByEm_num(em_num);

        List<DepartmentSalaryGet> sal_list = new ArrayList<>();

        for(int i = 0 ; i<list.size() ; i++){

            Employee employee = this.employeeService.queryEmployeeByEm_num(list.get(i).getEm_num());

            DepartmentSalaryGet departmentSalaryGet = new DepartmentSalaryGet();

            departmentSalaryGet.setEm_num(list.get(i).getEm_num());
            departmentSalaryGet.setEm_name(employee.getEm_name());
            if(employee.getJob_id() == 1){
                departmentSalaryGet.setJob_name("董事长");
            }
            else if(employee.getJob_id() == 6 || employee.getJob_id() == 7
                    || employee.getJob_id() == 8|| employee.getJob_id() == 9){
                departmentSalaryGet.setJob_name("产品经理");
            }
            else{
                departmentSalaryGet.setJob_name("职员");
            }
            departmentSalaryGet.setBase_salary(list.get(i).getBase_salary());
            departmentSalaryGet.setAttendance(list.get(i).getAttendance());
            departmentSalaryGet.setAttend_bonus(list.get(i).getAttend_bonus());
            departmentSalaryGet.setBonus(list.get(i).getBonus());
            departmentSalaryGet.setCalculate_salary(list.get(i).getCalculate_salary());
            departmentSalaryGet.setDeduction(list.get(i).getDeduction());
            departmentSalaryGet.setActual_salary(list.get(i).getActual_salary());
            departmentSalaryGet.setMonth(list.get(i).getMonth());

            sal_list.add(departmentSalaryGet);

        }

        return JsonResult.ok(sal_list);

    }


}
