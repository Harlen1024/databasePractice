package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Salary;

import java.util.List;

public interface SalaryService {

    List<Salary> getAllSalary();

    int insertSalary(Salary salary);

    Salary querySalaryByEm_numAndMonth(String em_num, int month);

    List<Salary> querySalaryByEm_num(String em_num);

}
