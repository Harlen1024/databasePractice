package com.springboot.salarymanager.controller;

import com.springboot.salarymanager.entity.Salary;
import com.springboot.salarymanager.excel.ReadExcelUtils;
import com.springboot.salarymanager.service.FileUpAndDownService;
import com.springboot.salarymanager.service.SalaryService;
import com.springboot.salarymanager.tool.filetool.IStatusMessage;
import com.springboot.salarymanager.tool.filetool.ResponseResult;
import com.springboot.salarymanager.tool.filetool.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

/**
 * 文件（excel）上传接口post
 * /upload/setFileUpload key = file
 */

@RestController
@CrossOrigin
@RequestMapping("/upload")
public class FileUploadController {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadController.class);

    @Autowired
    private FileUpAndDownService fileUpAndDownService;

    @Autowired
    private SalaryService salaryService;

    /*@Autowired
    private ArticleService articleService;*/

    @RequestMapping(value = "/setFileUpload", method = RequestMethod.POST)
    @ResponseBody
    public ResponseResult setFileUpload(@RequestParam(value = "file") MultipartFile file) {
        ResponseResult result = new ResponseResult();
        try {
            Map<String, Object> resultMap = upload(file);
            String file_name = resultMap.get("path").toString();
            System.out.println(file_name);
            if (!IStatusMessage.SystemStatus.SUCCESS.getMessage().equals(resultMap.get("result"))) {
                result.setCode(IStatusMessage.SystemStatus.PARAM.getCode());
                result.setMessage((String) resultMap.get("msg"));
                return result;
            }

            /*//图片上传成功即更新数据库对应的图片地址
            articleService.update(date,resultMap.get("path").toString());*/
            String filepath = file_name;
            ReadExcelUtils excelReader = new ReadExcelUtils(filepath);
            // 对读取Excel表格标题测试
//			String[] title = excelReader.readExcelTitle();
//			System.out.println("获得Excel表格的标题:");
//			for (String s : title) {
//				System.out.print(s + " ");
//			}

            Salary salary = new Salary();

            // 对读取Excel表格内容测试
            Map<Integer, Map<Integer,Object>> map = excelReader.readExcelContent();
            System.out.println("获得Excel表格的内容:");
            for (int i = 1; i <= map.size(); i++) {
                salary.setEm_num(map.get(i).get(0).toString());
                salary.setBase_salary(Integer.parseInt(map.get(i).get(1).toString().substring(0,map.get(i).get(1).toString().indexOf("."))));
                salary.setAttendance(Integer.parseInt(map.get(i).get(2).toString().substring(0,map.get(i).get(2).toString().indexOf("."))));
                salary.setBonus(Integer.parseInt(map.get(i).get(3).toString().substring(0,map.get(i).get(3).toString().indexOf("."))));
                salary.setAttend_bonus(Integer.parseInt(map.get(i).get(4).toString().substring(0,map.get(i).get(4).toString().indexOf("."))));
                salary.setCalculate_salary(Integer.parseInt(map.get(i).get(5).toString().substring(0,map.get(i).get(5).toString().indexOf("."))));
                salary.setDeduction(Integer.parseInt(map.get(i).get(6).toString().substring(0,map.get(i).get(6).toString().indexOf("."))));
                salary.setActual_salary(Integer.parseInt(map.get(i).get(7).toString().substring(0,map.get(i).get(7).toString().indexOf("."))));
                salary.setMonth(Integer.parseInt(map.get(i).get(8).toString().substring(0,map.get(i).get(8).toString().indexOf("."))));
                salaryService.insertSalary(salary);
            }

            result.setData(resultMap);

        } catch (ServiceException e) {
            e.printStackTrace();
            LOGGER.error(">>>>>>文件上传异常，e={}", e.getMessage());
            result.setCode(IStatusMessage.SystemStatus.ERROR.getCode());
            result.setMessage(IStatusMessage.SystemStatus.ERROR.getMessage());
        }catch (FileNotFoundException e) {
            System.out.println("未找到指定路径的文件!");
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private Map<String, Object> upload(MultipartFile file) throws ServiceException {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        try {
            if (!file.isEmpty()) {
                Map<String, Object> picMap = fileUpAndDownService.uploadPicture(file);
                if (IStatusMessage.SystemStatus.SUCCESS.getMessage().equals(picMap.get("result"))) {
                    return picMap;
                } else {
                    returnMap.put("result", IStatusMessage.SystemStatus.ERROR.getMessage());
                    returnMap.put("msg", picMap.get("result"));
                }
            } else {
                LOGGER.info(">>>>>>上传为空文件");
                returnMap.put("result", IStatusMessage.SystemStatus.FILE_UPLOAD_NULL.getMessage());
                returnMap.put("msg", IStatusMessage.SystemStatus.FILE_UPLOAD_NULL.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceException(IStatusMessage.SystemStatus.ERROR.getMessage());
        }
        return returnMap;
    }
}
