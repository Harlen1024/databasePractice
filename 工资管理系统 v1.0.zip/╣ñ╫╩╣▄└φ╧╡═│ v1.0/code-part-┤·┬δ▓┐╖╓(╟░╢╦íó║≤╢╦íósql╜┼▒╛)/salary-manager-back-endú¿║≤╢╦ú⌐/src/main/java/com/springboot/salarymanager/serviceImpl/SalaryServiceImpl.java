package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Salary;
import com.springboot.salarymanager.mapper.SalaryMapper;
import com.springboot.salarymanager.service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalaryServiceImpl implements SalaryService {

    @Autowired
    private SalaryMapper salaryMapper;

    @Override
    public List<Salary> getAllSalary() {

        List<Salary> list = this.salaryMapper.getAllSalary();

        return list;

    }

    @Override
    public int insertSalary(Salary salary){

        int temp = this.salaryMapper.insertSalary(salary);

        return temp;

    }

    @Override
    public Salary querySalaryByEm_numAndMonth(String em_num, int month){

        Salary salary = this.salaryMapper.querySalaryByEm_numAndMonth(em_num, month);

        return salary;
    }

    @Override
    public List<Salary> querySalaryByEm_num(String em_num){

        List<Salary> list = this.salaryMapper.querySalaryByEm_num(em_num);

        return list;

    }


}
