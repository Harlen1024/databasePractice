package com.springboot.salarymanager.mapper;

import com.springboot.salarymanager.entity.Salary;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface SalaryMapper {

    //查询全部
    @Select("select * from t_salary")
    List<Salary> getAllSalary();

    //添加新的工资记录
    @Insert("INSERT INTO t_salary (em_num, base_salary, attendance, bonus, attend_bonus, " +
            "calculate_salary, deduction, actual_salary, month) "
            + "VALUES (#{em_num}, #{base_salary}, #{attendance}, #{bonus}, #{attend_bonus}, " +
            "#{calculate_salary}, #{deduction}, #{actual_salary}, #{month})")
    int insertSalary(Salary salary);

    //按工号月份查询
    @Select("SELECT * FROM t_salary WHERE em_num = #{em_num} " +
            "AND month = #{month}")
    Salary querySalaryByEm_numAndMonth(@Param("em_num") String em_num, @Param("month")int month);

    //按工号查询
    @Select("SELECT * FROM t_salary WHERE em_num like '%${value}%'")
    List<Salary> querySalaryByEm_num(String em_num);

}
