package com.springboot.salarymanager.service;

import com.springboot.salarymanager.entity.Login;

public interface LoginService {

    Login queryReaderByEm_num(String em_num);

}
