package com.springboot.salarymanager.serviceImpl;

import com.springboot.salarymanager.entity.Job;
import com.springboot.salarymanager.mapper.JobMapper;
import com.springboot.salarymanager.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private JobMapper jobMapper;

    @Override
    public Job queryJobByJob_id(String job_id){

        Job job = this.jobMapper.queryJobByJob_id(job_id);

        return job;
    }
}
