/*
 Navicat Premium Data Transfer

 Source Server         : sa
 Source Server Type    : SQL Server
 Source Server Version : 14001000
 Source Host           : localhost\SQLEXPRESS:1433
 Source Catalog        : salary
 Source Schema         : dbo

 Target Server Type    : SQL Server
 Target Server Version : 14001000
 File Encoding         : 65001

 Date: 11/06/2019 21:14:24
*/


-- ----------------------------
-- Table structure for t_company
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_company]') AND type IN ('U'))
	DROP TABLE [dbo].[t_company]
GO

CREATE TABLE [dbo].[t_company] (
  [dep_id] int  NOT NULL,
  [total_turnover] bigint  NULL,
  [total_salary] bigint  NULL,
  [total_employee] int  NULL
)
GO

ALTER TABLE [dbo].[t_company] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for t_department
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_department]') AND type IN ('U'))
	DROP TABLE [dbo].[t_department]
GO

CREATE TABLE [dbo].[t_department] (
  [dep_id] int  NOT NULL,
  [dep_name] varchar(255) COLLATE Chinese_PRC_CI_AS  NULL,
  [dep_em] int  NULL,
  [dep_tot_turnover] bigint  NULL,
  [dep_tot_salary] bigint  NULL
)
GO

ALTER TABLE [dbo].[t_department] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for t_employee_info
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_employee_info]') AND type IN ('U'))
	DROP TABLE [dbo].[t_employee_info]
GO

CREATE TABLE [dbo].[t_employee_info] (
  [em_num] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_name] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_id] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_birth] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_nation] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_regist] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [em_addr] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [job_age] int  NOT NULL,
  [job_id] int  NULL
)
GO

ALTER TABLE [dbo].[t_employee_info] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Records of t_employee_info
-- ----------------------------
INSERT INTO [dbo].[t_employee_info] VALUES (N'223', N'王', N'352225', N'1989-01-11', N'汉', N'福建', N'福建', N'2', N'1')
GO


-- ----------------------------
-- Table structure for t_job
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_job]') AND type IN ('U'))
	DROP TABLE [dbo].[t_job]
GO

CREATE TABLE [dbo].[t_job] (
  [job_id] int  NOT NULL,
  [job_name] varchar(255) COLLATE Chinese_PRC_CI_AS  NULL,
  [job_dep] int  NULL,
  [base_salary] int  NULL
)
GO

ALTER TABLE [dbo].[t_job] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for t_login
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_login]') AND type IN ('U'))
	DROP TABLE [dbo].[t_login]
GO

CREATE TABLE [dbo].[t_login] (
  [em_num] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [password] varchar(255) COLLATE Chinese_PRC_CI_AS  NULL,
  [type] int  NULL
)
GO

ALTER TABLE [dbo].[t_login] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Table structure for t_salary
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[t_salary]') AND type IN ('U'))
	DROP TABLE [dbo].[t_salary]
GO

CREATE TABLE [dbo].[t_salary] (
  [em_num] varchar(255) COLLATE Chinese_PRC_CI_AS  NOT NULL,
  [base_salary] int  NULL,
  [attendance] int  NULL,
  [bonus] int  NULL,
  [attend_bonus] int  NULL,
  [calculate_salary] int  NULL,
  [deduction] int  NULL,
  [actual_salary] int  NULL
)
GO

ALTER TABLE [dbo].[t_salary] SET (LOCK_ESCALATION = TABLE)
GO


-- ----------------------------
-- Procedure structure for insert_new_employee
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[insert_new_employee]') AND type IN ('P', 'PC', 'RF', 'X'))
	DROP PROCEDURE[dbo].[insert_new_employee]
GO

CREATE PROCEDURE [dbo].[insert_new_employee]
  @empNum AS varchar ,
  @name AS varchar ,
  @IDNum AS varchar ,
  @birthDate AS varchar ,
  @nation AS varchar ,
  @registAddr AS varchar ,
  @address AS varchar ,
  @jobAge AS int ,
  @jobNum AS int 
AS
DECLARE
	@baseSalary int;
BEGIN
	INSERT INTO t_employee_info VALUES(@empNum, @name, @IDNum, @birthDate, @nation,@registAddr, @address, @jobAge, @jobNum);
	SET @baseSalary=(SELECT base_salary FROM t_job WHERE job_id=@jobNum);
	INSERT INTO t_salary(em_num, base_salary) VALUES(@empNum, @baseSalary);
END
GO


-- ----------------------------
-- Primary Key structure for table t_company
-- ----------------------------
ALTER TABLE [dbo].[t_company] ADD CONSTRAINT [PK__t_compan__BB4BD8F857629B03] PRIMARY KEY CLUSTERED ([dep_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table t_department
-- ----------------------------
ALTER TABLE [dbo].[t_department] ADD CONSTRAINT [PK__t_depart__BB4BD8F8B795F479] PRIMARY KEY CLUSTERED ([dep_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table t_employee_info
-- ----------------------------
ALTER TABLE [dbo].[t_employee_info] ADD CONSTRAINT [PK__t_employ__187D7C294E40771B] PRIMARY KEY CLUSTERED ([em_num])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table t_job
-- ----------------------------
ALTER TABLE [dbo].[t_job] ADD CONSTRAINT [PK__t_job__6E32B6A529989B71] PRIMARY KEY CLUSTERED ([job_id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table t_login
-- ----------------------------
ALTER TABLE [dbo].[t_login] ADD CONSTRAINT [PK__t_login__9C26D4D71D561E2F] PRIMARY KEY CLUSTERED ([em_num])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO


-- ----------------------------
-- Primary Key structure for table t_salary
-- ----------------------------
ALTER TABLE [dbo].[t_salary] ADD CONSTRAINT [PK__t_salary__187D7C29DE2327E1] PRIMARY KEY CLUSTERED ([em_num])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
GO

