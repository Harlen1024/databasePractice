$(function(){
	var h=window.innerHeight|| document.documentElement.clientHeight|| document.body.clientHeight;
	
	h-=80;
	
	$("#left_content").css("height",h+"px");
	
	$("#right_content").css("height",h+"px");
		
	$("#left_content").children().click(function(){
		var $this=this;
		$("#left_content").children().each(function(){
			if($(this).attr("class")=="right_content_g"){
				
			}
			if(this==$this){
				$("#"+$(this).attr("class")).css("display","flex");
				$(this).css("background-color","skyblue");
				$(this).css("color","black");
			}
			else{
				$("#"+$(this).attr("class")).css("display","none");
				$(this).css("background-color","white");
				$(this).css("color","darkgray");
			}
		})
	})
	$("#left_content").children(".right_content_a").click();
	
	var storage=window.localStorage;
	var type=storage.getItem("user_type");
	console.log(type);
	if(type==3){
		$(".right_content_g").remove();
		$("#right_content_g").remove();
	}
	//选择文件，准备上传
	layui.use('upload', function(){
	  var upload = layui.upload;
	  //执行实例
	  var uploadInst = upload.render({
		field:"file",
		elem:'#test1',//绑定元素
		auto:false,
		accept:"file",
		bindAction:"#af",
		url: 'http://47.95.3.253:8080/salary-manager/upload/setFileUpload' ,//上传接口
		choose:function(obj){
				$("#af").click();
		},
		data:{
	
		},
		done: function(res){
			console.log("done");
		  //上传完毕回调
		}
		,error: function(){
		  //请求异常回调
		}
	  });
	});
	
	
	//加载个人信息
	var storage=window.localStorage;//创建访问localStorage的对象
	var user=storage.getItem("user_now");
	

	axios({
		  method: 'get',
		  url:'http://47.95.3.253:8080/salary-manager/api/query/employee/em_num/'+user,
		  responseType:'json',
	
	}).then(function(response) {
		$("#name").html(response.data.data.em_name);
		$("#user_name").html(response.data.data.em_name);
		
		if(response.data.data.em_sex==0){
			$("#sex").html("男");
		}
		else{
			$("#sex").html("女");
		}
		
		$("#id_num").html(response.data.data.em_id);
		$("#born").html(response.data.data.em_birth);
		$("#nation").html(response.data.data.em_nation);
		$("#where").html(response.data.data.em_regist);
		$("#home").html(response.data.data.em_addr);
		$("#work_age").html(response.data.data.job_age);
		$("#work_id").html(response.data.data.em_num);
		
		//加载上半部分信息
		axios({
			method: 'get',
			url:'http://47.95.3.253:8080/salary-manager/api/query/job/job_id/'+response.data.data.job_id,
			responseType:'json',
		}).then(function(response){
			if(response.data.data.job_dep==1)
			$("#apartment").html("董事部");
			
			if(response.data.data.job_dep==2)
			$("#apartment").html("技术部");
			
			if(response.data.data.job_dep==3)
			$("#apartment").html("运营部");
			
			if(response.data.data.job_dep==4)
			$("#apartment").html("销售部");
			
			if(response.data.data.job_dep==5)
			$("#apartment").html("行政部");
			
			axios({
				method: 'get',
				url:'http://47.95.3.253:8080/salary-manager/api/query/dep/dep_id/'+response.data.data.job_dep,
				responseType:'json',
			}).then(function(response){
				
				var storage=window.localStorage;
				storage.setItem("job_id",response.data.data.dep_id);
			});
			
			$("#stage").html(response.data.data.job_name);
			
		}).catch(function (error){
			alert("部门链接错误");
		});
		var	i=0;
		console.log("a:"+$('#month>select option:selected').val());
		axios({
			method: 'get',

			url:'http://47.95.3.253:8080/salary-manager/api/query/salary/em_num/'+response.data.data.em_num+"/"+$('#month>select option:selected').val(),
			responseType:'json',
		}).then(function(response){
			if(response.data.data==null){
				if(i!=0)
				alert("无"+$('#month>select option:selected').val()+"月份工资记录");
				i++;
				$("#Attendance_days").html("");
				$("#bonus").html("");
				
				$("#Perfect_attendance").html("");
				$("#Basic_salary").html("");
				$("#Should_pay").html("");
				$("#Deduction_of_wages").html("");
				$("#Real_wages").html("");
			}
			else{
				$("#Attendance_days").html(response.data.data.attendance);
				$("#bonus").html(response.data.data.bonus);
				console.log(response.data.data.attend_bonus);
				$("#Perfect_attendance").html(response.data.data.attend_bonus);
				$("#Basic_salary").html(response.data.data.base_salary);
				$("#Should_pay").html(response.data.data.actual_salary);
				$("#Deduction_of_wages").html(response.data.data.deduction);
				$("#Real_wages").html(response.data.data.actual_salary);
			}
			
		}).catch(function (error){
			console.log(error);
			alert("工资链接错误");
		});
		
	}).catch(function (error) {
		alert("个人信息链接错误");
	});
	
	
	
	//月份选项栏改变 
	 $("#month select").change(function(){
			
			axios({
				method: 'get',
				url:'http://47.95.3.253:8080/salary-manager/api/query/salary/em_num/'+user+"/"+$('#month>select option:selected').val(),
				responseType:'json',
			}).then(function(response){
				if(response.data.data==null){
					alert("无"+$('#month>select option:selected').val()+"月份工资记录");
					$("#Attendance_days").html("");
					$("#bonus").html("");
					
					$("#Perfect_attendance").html("");
					$("#Basic_salary").html("");
					$("#Should_pay").html("");
					$("#Deduction_of_wages").html("");
					$("#Real_wages").html("");
				}
				else{
					$("#Attendance_days").html(response.data.data.attendance);
					$("#bonus").html(response.data.data.bonus);
					console.log(response.data.data.attend_bonus);
					$("#Perfect_attendance").html(response.data.data.attend_bonus);
					$("#Basic_salary").html(response.data.data.base_salary);
					$("#Should_pay").html(response.data.data.actual_salary);
					$("#Deduction_of_wages").html(response.data.data.deduction);
					$("#Real_wages").html(response.data.data.actual_salary);
				}
				
			}).catch(function (error){
				alert("月份链接错误");
			});
    });
	//退出按钮
	$("#login_out").click(function(){
		var storage=window.localStorage;
		storage.clear();
		window.open("Sign.html");
		window.close();
	});
	
	//个人信息点击跳转
	$("#user_name").click(function(){
		$(".right_content_f").click();
	})
	
	//企业总情况
	axios({
		method: 'get',
		url:'http://47.95.3.253:8080/salary-manager/api/query/company/year/2019',
		responseType:'json',
	}).then(function(response){
		
		$("#total_number>div:last").html(response.data.data.total_employee);
		$("#Turnover>div:last").html(response.data.data.total_turnover);
		$("#gross_wage>div:last").html(response.data.data.total_salary);
		$("#department>div:last").html("4");
	}).catch(function (error){
	});
	
	//加载部门信息
		var storage=window.localStorage;
		var type=storage.getItem("user_type");
		if(type==1){
			getall(1,"right_content_b");
			getall(2,"right_content_c");
			getall(3,"right_content_d");
			getall(4,"right_content_e");
		}
		else if(type==2){
			var storage=window.localStorage;//创建访问localStorage的对象
			var id=storage.getItem("job_id");
			
			axios({
				method: 'get',
				url:'http://47.95.3.253:8080/salary-manager/api/query/dep/dep_id/'+id,
				responseType:'json',
			}).then(function(response){
				console.log(response.data.data.dep_name);
				var name=response.data.data.dep_name;
				if(name=="技术部"){
						getall(1,"right_content_b");
				}
				else if(name=="运营部"){
					getall(2,"right_content_c");
				}
				else if(name=="销售部"){
					getall(3,"right_content_d");
				}
				else if(name=="行政部"){
					getall(4,"right_content_e");
				}
			});
		}
	//搜查
		$("#search_by_id_sure").click(function(){
				$(".search_show").empty();
			
			console.log($("#search_by_id").val());
			axios({
				method: 'get',
				url:'http://47.95.3.253:8080/salary-manager/api/query/salary/em_num/'+$("#search_by_id").val(),
				responseType:'json',
			}).then(function(response){
				console.log(response.data.data);
				if(response.data.data.length==0) alert("无该员工信息");
				else{
					for(var i=0;i<response.data.data.length;i++){
						var id=$("<div></div>");
						var label=$("<p></p>").text("员工号：");
						var id_one=$("<p></p>").text(response.data.data[i].id);
						id.append(label);
						id.append(id_one);
						id.attr("class","id");
						
						
						var em_num=$("<div></div>");
						var label=$("<p></p>").text("登陆账号：");
						var em_num_one=$("<p></p>").text(response.data.data[i].em_num);
						em_num.append(label);
						em_num.append(em_num_one);
						em_num.attr("class","em_num");
						
						var base_salary=$("<div></div>");
						var label=$("<p></p>").text("基本工资：");
						var base_salary_one=$("<p></p>").text(response.data.data[i].base_salary);
						base_salary.append(label);
						base_salary.append(base_salary_one);
						base_salary.attr("class","base_salary");
						
						var attendance=$("<div></div>");
						var label=$("<p></p>").text("出勤：");
						var attendance_one=$("<p></p>").text(response.data.data[i].attendance);
						attendance.append(label);
						attendance.append(attendance_one);
						attendance.attr("class","attendance");
						
						
						var bonus=$("<div></div>");
						var label=$("<p></p>").text("奖金：");
						var bonus_one=$("<p></p>").text(response.data.data[i].bonus);
						bonus.append(label);
						bonus.append(bonus_one);
						bonus.attr("class","bonus");
						
						var attend_bonus=$("<div></div>");
						var label=$("<p></p>").text("出勤奖金：");
						var attend_bonus_one=$("<p></p>").text(response.data.data[i].attend_bonus);
						attend_bonus.append(label);
						attend_bonus.append(attend_bonus_one);
						attend_bonus.attr("class","attend_bonus");
						
						
						
						var calculate_salary=$("<div></div>");
						var label=$("<p></p>").text("应发工资：");
						var calculate_salary_one=$("<p></p>").text(response.data.data[i].calculate_salary);
						calculate_salary.append(label);
						calculate_salary.append(calculate_salary_one);
						calculate_salary.attr("class","calculate_salary");
						
						var deduction=$("<div></div>");
						var label=$("<p></p>").text("扣除工资：");
						var deduction_one=$("<p></p>").text(response.data.data[i].deduction);
						deduction.append(label);
						deduction.append(deduction_one);
						deduction.attr("class","deduction");
						
						var actual_salary=$("<div></div>");
						var label=$("<p></p>").text("实发工资：");
						var actual_salary_one=$("<p></p>").text(response.data.data[i].actual_salary);
						actual_salary.append(label);
						actual_salary.append(actual_salary_one);
						actual_salary.attr("class","actual_salary");
						
						var month=$("<p></p>").text("月份："+response.data.data[i].month);
						
						var div=$("<div></div>");
						div.attr("id",response.data.data[i].id);
						div.attr("class",response.data.data[i].month);
						
						
						
						div.append(em_num);
						div.append(base_salary);
						div.append(attendance);
						div.append(bonus);
						div.append(attend_bonus);
						div.append(calculate_salary);
						div.append(deduction);
						div.append(actual_salary);
						div.append(month);
						$(".search_show").append(div);
					}
				}
			});
		})

		$("#edit").click(function(){
			if($(this).html()=="编辑"){
				$(this).html("确认");
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#name").html());
				$("#name").html("");
				$("#name").append($new_node);
				
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#sex").html());
				$("#sex").html("");
				$("#sex").append($new_node);
				
				$new_node=$("<input type='text' size='40' />");
				$new_node.val($("#id_num").html());
				$("#id_num").html("");
				$("#id_num").append($new_node);
				
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#born").html());
				$("#born").html("");
				$("#born").append($new_node);
				
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#nation").html());
				$("#nation").html("");
				$("#nation").append($new_node);
				
				$new_node=$("<input type='text' size='10' />");
				$new_node.val($("#where").html());
				$("#where").html("");
				$("#where").append($new_node);
				
				
				$new_node=$("<input type='text' size='40' />");
				$new_node.val($("#home").html());
				$("#home").html("");
				$("#home").append($new_node);
				
			}
			else if($(this).html()=="确认"){
				$(this).html("编辑");
				var text=$("#name>input").val();
				$("#name").empty();
				console.log(text);
				$("#name").html(text);
				
				var text=$("#sex>input").val();
				$("#sex").empty();
				$("#sex").html(text);
				
				
				var text=$("#id_num>input").val();
				$("#id_num").empty();
				$("#id_num").html(text);
				
				var text=$("#born>input").val();
				$("#born").empty();
				$("#born").html(text);
				
				var text=$("#nation>input").val();
				$("#nation").empty();
				$("#nation").html(text);

				var text=$("#where>input").val();
				$("#where").empty();
				$("#where").html(text);
			
				var text=$("#home>input").val();
				$("#home").empty();
				$("#home").html(text);
				
			
				var storage=window.localStorage;
				var num=storage.getItem("user_now");
				
				var m=$("#name").html();
				var sex;
				if($("#sex").html()=="男") sex="0";
				else sex="1";
				
				var i=$("#id_num").html();
				var b=$("#born").html();
				var n=$("#nation").html();
				var w=$("#where").html();
				var h=$("#home").html();
	
				axios({
					method: 'post',
					url:'http://47.95.3.253:8080/salary-manager/api/update/employee',
					responseType:'json',
					data:{
						 em_num: num,
						 em_name: m,
						 em_sex: sex,
						 em_id: i,
						 em_birth: b,
						 em_nation: n,
						 em_regist: w,
						 em_addr: h
					}
					}).then(function(response){
						console.log(response.data.data);
					});
				}
		});

})

function getall(i,who){
	
	axios({
		method: 'get',
		url:'http://47.95.3.253:8080/salary-manager/api/query/salary/department/'+i,
		responseType:'json',
	}).then(function(response){
		for(var i=1;i<=response.data.data.length;i++){
			
			
			var tr=$("<tr></tr>");
			var temp=$("<td></td>").html(i);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].em_num);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].em_name);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].job_name);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].base_salary);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].attendance);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].bonus);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].attend_bonus);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].calculate_salary);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].deduction);
			tr.append(temp);
			
			var temp=$("<td></td>");
			temp.html(response.data.data[i].actual_salary);
			tr.append(temp);

			var temp=$("<td></td>");
			temp.html(response.data.data[i].month);
			tr.append(temp);
			
			$("#"+who+" .show_table").append(tr);
		}
	}).catch(function (error){
	});
}