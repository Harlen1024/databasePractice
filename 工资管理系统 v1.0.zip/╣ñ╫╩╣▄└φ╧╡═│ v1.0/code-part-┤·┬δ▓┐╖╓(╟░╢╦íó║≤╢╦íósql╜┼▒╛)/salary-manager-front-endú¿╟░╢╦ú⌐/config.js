require.config({
  baseUrl: "lib",
  paths: {
    "jquery": "jq/jquery.min",
    "echarts":"echarts/echarts.common.min"
  }　　
});
