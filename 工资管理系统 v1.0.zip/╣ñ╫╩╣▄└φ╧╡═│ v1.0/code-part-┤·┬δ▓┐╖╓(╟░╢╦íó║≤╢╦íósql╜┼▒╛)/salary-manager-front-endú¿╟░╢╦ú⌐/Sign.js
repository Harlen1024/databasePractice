$(function(){
	//适应屏幕
	var h=window.innerHeight|| document.documentElement.clientHeight|| document.body.clientHeight;
	$("#top").css("height",h+"px");
	$("#pic").css("height",h+"px");
	$("#pic").css("background-size","100% "+h+"px");
	
	var id=new Vue({
		el:"#user",
		data:{
			obj:null
		},
	})
	
	var pass=new Vue({
		el:"#password",
		data:{
			obj:null
		},
	})
	
	$("#make_sure").click(function(){
		console.log(id.$data.obj+" "+pass.$data.obj);
		var id_num=id.$data.obj;
		var pass_num=pass.$data.obj;
		//访问数据库 验证账号密码
		axios({
			  method: 'post',
			  url:'http://47.95.3.253:8080/salary-manager/api/append/login?em_num='+id_num+"&password="+pass_num,
			  responseType:'json',

		}).then(function(response) {
			console.log(response);
			if(response.data.data.login_state=="true"){
					var storage=window.localStorage;//创建访问localStorage的对象
					storage.setItem("user_type",response.data.data.type);
					storage.setItem("user_now",response.data.data.em_num);
					
					window.open("Show.html");
					window.close();

				
			}
			else if(response.data.data.login_state=="false"){
				alert("账号和密码不匹配");
			}
			
		}).catch(function (error) {
			alert("链接错误");
		});

		
	})
	
})