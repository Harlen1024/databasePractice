	 var myChart;
	function echartStr(names,brower){
		// 基于准备好的dom，初始化echarts实例
		if (myChart != null && myChart != "" && myChart != undefined) {  
	        myChart.dispose();  
	    } 
	    myChart = echarts.init(document.getElementById('main'));
	    // 指定图表的配置项和数据
	    var option = {
		    title : {
		        text: '',
		        subtext: '',
		        x:'center'
		    },
		    tooltip : {
		        trigger: 'item',
		        formatter: "{a} <br/>{b} : {c} ({d}%)"
		    },
		    legend: {
		        orient: 'vertical',
		        left: 'left',
		        data: names
		    },
		    series : [
		        {
		            name: '访问来源',
		            type: 'pie',
		            radius : '80%',
		            center: ['50%', '50%'],
		            data: brower,
		            itemStyle: {
		                emphasis: {
		                    shadowBlur: 10,
		                    shadowOffsetX: 0,
		                    shadowColor: 'rgba(0, 0, 0, 0.5)'
		                }
		            },
		            label: {
	                normal: {
	                    show: false,
	                }
	            },
		        }
		    ]
		};
	
	    // 使用刚指定的配置项和数据显示图表。
	    myChart.setOption(option);
	};
	
	//缺陷分类
	function qxfl(that){
		var brower = [],
			names = [];
		var index = $(that).data('index');
			
		axios({
			method: 'get',
			url:'http://47.95.3.253:8080/salary-manager/api/query/department/all',
			responseType:'json',
		}).then(function(response){
			
			//请求成功时执行该函数内容，result即为服务器返回的json对象
			//'result.list' + index 请求json的其中一个
			//eval() 将对应的字符串解析成JS代码并运行
			for(var i=0;i<5;i++){
				 names.push(response.data.data[i].dep_name);    //挨个取出类别并填入类别数组 
					console.log(response.data.data[i].dep_name);
				brower.push({
				    name: response.data.data[i].dep_name,
				    value: response.data.data[i].dep_em
				});
			}
			echartStr(names,brower);
		}).catch(function (errorMsg){
			alert("图表请求数据失败!");
		});
	}
